import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.math.*;
import java.text.*;

class node {
	public Double posx, posy;
	public int numLinks;
	public int links[] = new int[4];    
}