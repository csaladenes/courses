function Duder(host, ID, name)

import java.net.Socket
import java.io.*

[sock,sock_input,sock_output,numNodes,world,currentNode] = getConnection(3000+ID,host,name);

play(sock_input,sock_output,numNodes,world,currentNode);

try
    sock_input.close;
	sock_output.close;
	sock.close;
catch
    disp('Problem closing the sockets');
end

return;

function play(sock_input,sock_output,numNodes,world,currentNode)
    % set up random number generated
    
    while (true)
        % read the status of the world
        [travelCost payout tollCharge currentNode nodeUtilities,linkState,done] = readStatus(sock_input);
        
        if (done == 1)
            break;
        end
        
        updateInternalModels();
        
        % act
        act(sock_output, world, currentNode, nodeUtilities);
        
    end
return


% This function is called after new information is obtained about the world
% Information is stored in the information variables defined at the beginning of the class
% ********* You should use this function to update you agent's estimates/model of the world (if you choose to model the world)
function updateInternalModels()

return

function act(sock_output,world,currentNode,nodeUtilities)
    a = selectAction(world, currentNode);
    
    destination = world(currentNode,4+a) + 1;
    if (nodeUtilities(destination) > 0)
        buf = sprintf('%i Y', a);
    else
        buf = sprintf('%i N', a);
    end
    
    disp(buf);
    sock_output.println(buf);

return

% This function selects the next link to traverse from currentNode
%      1 means the agent selects link(1)
%      2 means the agent selects link(2)
% ********* You will need to modify this function
function a = selectAction(world, currentNode)
    numLinks = round(world(currentNode,3));
    a = randi(numLinks) - 1;
return


% You shouldn't modify this function
% This function gets an update from the server each time your car reaches a new node
% The server supplies you with the following information:
%       1. Reward/cost information: travelCost: the cost (measured in happiness units) you incurred for traveling over the last link
%                                   payout: the number of happiness units you got for arriving at the current node
%                                   tollCharge: the amount of toll charge you incurred for traveling the latest link
%       2. currentNode: the current node position your car is at in the world (value between 1-4)
%       3. currentUtilitiesforVisitingNode [array of 4]: The number of happiness units you will get in the future for arriving at each of the 4 nodes    
%       4. linkState: first item is the average number of vehicles that were on the link just traversed; second number is the capacity of the link
function [travelCost,payout,tollCharge,currentNode,nodeUtilities,linkState,done] = readStatus(sock_input)
    done = 0;
    travelCost = 0;
    payout = 0;
    tollCharge = 0;
    currentNode = 0;
    nodeUtilities = zeros(4,1);
    linkState = [];
try
    % read in the costs and rewards
    strCosts = sock_input.readLine();    
    remain = char(strCosts);
    [str, remain] = strtok(remain,' ');
    if (str(1) == 'q')
        done = 1;
        return;
    end
    
    [str, remain] = strtok(remain,' ');
    travelCost = str2num(str);
    [str, remain] = strtok(remain,' ');
    payout = str2num(str);
    [str, remain] = strtok(remain,' ');
    tollCharge = str2num(str);
    
    % read in the Position
    strPosition = sock_input.readLine();
    remain = char(strPosition);
    [str, remain] = strtok(remain,' ');
    [str, remain] = strtok(remain,' ');
    currentNode = str2num(str) + 1;
    
    % read in the nodeUtilities
    strUtilities = sock_input.readLine();
    remain = char(strUtilities);
    [str, remain] = strtok(remain,' ');
    for i=1:4
        [str, remain] = strtok(remain,' ');
        nodeUtilities(i) = str2num(str);
    end
    strLinkState = sock_input.readLine();
    remain = char(strLinkState);
    [str, remain] = strtok(remain,' ');
    [str, remain] = strtok(remain,' ');
    linkState = [str2num(str) str2num(remain)];
catch
    done = 1;
    disp('I/O error');
end

return