
% **********************************************************************************
%
%       Theoretically, you shouldn't have to alter anything to this function
%           unless you want to change the color of your agent
%
% **********************************************************************************

function [sock,sock_input,sock_output,numNodes,world,currentNode] = getConnection(port, host, name)

import java.net.Socket
import java.io.*

world = [];

try
    sock = Socket(host,port);
    sock_input = BufferedReader(InputStreamReader(sock.getInputStream()));
    sock_output = PrintWriter(sock.getOutputStream(), true);
    numNodesStr = sock_input.readLine();
    numNodes = str2num(numNodesStr);
    for i=1:numNodes
        
        nodeStr = sock_input.readLine();
        remain = char(nodeStr);

        [str, remain] = strtok(remain,' ');
        if isempty(remain), break; end
        remain2 = remain;
        n = [str2num(str)];
        while true
            [str, remain2] = strtok(remain2,' ');
            if isempty(str), break; end
            n = [n str2num(str)];
        end        

        
        % pad with -1
        [x d] = size(n);
        for i=(d+1):7
            n = [n -1];
        end
         
        world = [world; n];
    end
    world
    currentNode = str2num(sock_input.readLine()) + 1;
    
    buf = sprintf('%s\n0.0 0.0 0.0', name);
    sock_output.println(buf);
catch
    if ~isempty(sock)
        sock.close;
        disp('got a socket problem');
    end
end

return;