#include "defs.h"
#include "node.h"
#include "Agent.h"

//#include <string>
//#include <vector>
//#include <cstdlib>
//#include <sstream>
//#include<iomanip>

#define BORDER      90
#define DATA_AREA   200

#define BLOCKADE_COST   0

typedef struct {
    double x, y;
} Point;


void worldVariables();
void Resize(int width, int height);
void SpecialKeys(int key, int x, int y);
void RegularKeys(unsigned char key, int x, int y);
void DrawText(GLint x, GLint y, char* s, GLfloat r, GLfloat g, GLfloat b);
void DrawText12(GLint x, GLint y, char* s, GLfloat r, GLfloat g, GLfloat b);
void DrawText24(GLint x, GLint y, char* s, GLfloat r, GLfloat g, GLfloat b);
void Display();
void DrawWorld(void);
void DrawAgents();
void DrawNodeLabel(GLfloat x, GLfloat y, char *s, GLfloat r, GLfloat g, GLfloat b);
std::string numToLetter(int n);
void DrawGraph();
void DrawLinkStatus();
void DrawLinkStatus2();
//void LogAgentStatus();
void DrawInfoStatus();
void DrawTolls();
void drawClock();
void drawWorth();
void drawAgentWorth(int id);
//void LogData();
void FillBox(int x, int y, int width, int height);
void OutlineBox(int x, int y, int width, int height);
void drawCircle(int x, int y, int r);
void drawPartialCircle(int x, int y, double pi_i, double pi_f, int r);
void drawCircleOutline(int x, int y, int r);
void drawArrow(double x, double y, double degree, int size);
void myMouse(int button,int state,int x,int y);

void Controls();

void initCounts();

int WIDTH, HEIGHT;


// keep copies of the world and agents
//Node worldCopy[100];
//int numWorldNodesCopy = 0;
int highx = -99999, lowx = 99999, highy = -99999, lowy = 99999;

struct _timeb empieza;
double empiezaConv;

static float xx = 0.0f;
static float yy = 0.0f;

static float red = 0.4f;
static float green = 0.4f;
static float blue = 0.4f;

bool onleft;

int winid;

extern int gameLength;

//extern int running_model_type;
//extern double highScores[5];
//extern char highNames[5][1024];

extern bool done;//, highScoreFlag;
//extern char highScoreMessage[1024], yourPseudoname[1024];
//extern pthread_mutex_t count_mutex;
extern int sitters[4];
//HWND myneededhwnd = 0;
//GLuint theFont, theFont25;
//HDC	FontDC;

//int totalTollChanges = 0, tollChangesHistory[30];
//double *tollAveHistory;

//extern FILE *fpCON;

//double tollChangeFund = 30.0, tollChangeInc = 0.7;

//extern bool tollLimitations;

extern Node *world[100];
extern int numWorldNodes;
extern Agent **agents;
extern int numAgents;

int agentCountNums[100][100];


// ****************************************** //
//											  //
//				OPEN_GL STUFF				  //
//											  //
// ****************************************** //

void initGl(int argc, char *argv[], const char *title) {
    done = false;
    
    int i;
    
    worldVariables();
    
	glutInit(&argc, argv);
    
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
	WIDTH = 2 * BORDER + (highx - lowx) * 160;//wwidth * SQUARE + 2 * BORDERX;
    //printf("WIDTH = %i\n", WIDTH);
	HEIGHT = 2 * BORDER + (highy - lowy) * 90;//wheight * SQUARE + 2 * (BORDERY + 20) + REWARD_SPACE;
	//printf("high (%i, %i); low = (%i, %i)\n", highx, highy, lowx, lowy);
	//printf("width = %i; height = %i\n", WIDTH, HEIGHT);
    
	initCounts();
	
	glutInitWindowPosition(50, 50);
	glutInitWindowSize(WIDTH, HEIGHT+DATA_AREA);
    
	winid = glutCreateWindow(title);
    
	glutReshapeFunc(Resize);
	glutDisplayFunc(DrawWorld);	
	glutIdleFunc(DrawWorld);
	
	glutSpecialFunc(SpecialKeys);
	glutKeyboardFunc(RegularKeys);
	glutMouseFunc(myMouse);

	//myneededhwnd = FindWindow("GLUT", title);
	//FontDC = GetDC(myneededhwnd);
	//theFont_Helvetica12 = FontCreateBitmaps(FontDC, "Helvetica", 12, FW_NORMAL, 0);
	//theFont_Helvetica18 = FontCreateBitmaps(FontDC, "Helvetica", 18, FW_NORMAL, 0);
	//theFont_Helvetica24 = FontCreateBitmaps(FontDC, "Helvetica", 24, FW_NORMAL, 0);
		
	glutMainLoop();
}

void initCounts() {

	_ftime(&empieza);
	empiezaConv = (double)(empieza.time) + ((double)empieza.millitm / 1000.0);

	//gettimeofday(&empieza, NULL);    
    //empiezaConv = empieza.tv_sec + (empieza.tv_usec / 1000000.0);
    
	//lastRevenueRead = empiezaConv;
    
	//oldTime = 0;

	//int i;
	//for (i = 0; i < 30; i++) {
	//	recentCount[i] = 0;
	//}
}

void worldVariables() {
	int i, j;
	for (i = 0; i < numWorldNodes; i++) {
		if (world[i]->posx > highx)
			highx = world[i]->posx;
		if (world[i]->posx < lowx)
			lowx = world[i]->posx;
		
		if (world[i]->posy > highy)
			highy = world[i]->posy;
		if (world[i]->posy < lowy)
			lowy = world[i]->posy;
	}
}
/*
void initAgentsCopy(int tipo, int _numAgents) {
	int i;
	
    agentCopy = new Agent*[_numAgents];
    for (i = 0; i < _numAgents; i++) {
        if (tipo == RANDOM_TYPE){
            agentCopy[i] = new RandomAgent();
        }
        else if (tipo == DIJKSTRA_TYPE){
            agentCopy[i] = new Dijkstra();
        }
        else if(tipo == STATIC_TYPE){
            agentCopy[i] = new Static();
        }
        else{
            printf("type not found\n");
            exit(1);
        }
    }
}
*/
void Display() {
	DrawWorld();
}

void DrawWorld(void) {
	glPushMatrix();

	glClearColor(0.3f, 0.7f, 0.3f, 0.0f);
	//glClearColor(0.1f, 0.4f, 0.1f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);	

    glEnable (GL_BLEND);
    glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    
    //Controls();
    
	DrawGraph();
	DrawAgents();
	DrawLinkStatus2();
	
    //DrawInfoStatus();
    DrawTolls();
    
    drawClock();
    drawWorth();

	glPopMatrix();
	glFlush();
	glutSwapBuffers();
    
	//LogAgentStatus();
	//LogData();
	
    //usleep(500);    
}


void DrawNodeLabel(GLfloat x, GLfloat y, char *s, GLfloat r, GLfloat g, GLfloat b) {
    char *cha;
    glColor3f(r,g,b);
	glRasterPos2f(x+1, y);
	glDisable(GL_LIGHTING);
	
    for (cha=s; *cha; cha++) {
		//glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *cha);
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *cha);
    }
}

std::string numToLetter(int n){
    if(n >= 1 && n <= 26){
		std::string str[26] = {"A","B", "C", "D", "E", "F","G","H","I","J","K","L","M","N","O",
			"P","Q","R","S","T","U","V","W","X","Y","Z"};
        return str[n-1];
    }else{
        return "";
    }
}

void DrawGraph() {
	int i, j;
	
	double pi = 3.141593;
	double cx, cy, cx2, cy2, slope, degree, ax, ay;
	double scaley = (HEIGHT - (2 * BORDER)) / (double)(highy - lowy);
	double scalex = (WIDTH - (2 * BORDER)) / (double)(highx - lowx);
	//printf("scalex = %d, scaley = %d\n",scalex, scaley);
	//printf("------------------------------------------\n");
	double radius = 25 * (scalex / 200.0);
	if (radius > 40)
		radius = 40;
	//printf("radius = %d\n", radius);
	for (i = 0; i < numWorldNodes; i++) {
		cx = BORDER + scalex * world[i]->posx;
		cy = BORDER + DATA_AREA + scaley * world[i]->posy;
        
		for (j = 0; j < world[i]->numLinks; j++) {
			cx2 = BORDER + scalex * world[world[i]->links[j]]->posx;
			cy2 = BORDER + DATA_AREA + scaley * world[world[i]->links[j]]->posy;
			
			if ((world[i]->linkTypes[j] == STRAIGHT) || (world[i]->linkTypes[j] == TWO_WAY)) {
				if ((world[i]->linkTypes[j] == TWO_WAY)) {// && (cx == cx2)) {
					if (cy < cy2) {
						cx = cx + 10 * (scalex / 200.0);
						cx2 = cx2 + 10 * (scalex / 200.0);
					}
					else {
						cx = cx - 10 * (scalex / 200.0);
						cx2 = cx2 - 10 * (scalex / 200.0);
					}
				}
				//printf("cx= %d, cy = %d\n", cx,cy);
				//printf("cx2= %d, cy2 = %d\n", cx2,cy2);
				//printf("-------------------------------\n");

				//glEnable(GL_LINE_SMOOTH);
				
                float width = world[i]->capacity[j] / 0.3;
				//printf("width=%f\n", width);
                glLineWidth((int)(width));	
                if (world[i]->linkStatus[j])
                    glColor3f(0.75, 0.75, 0.6);
                else
                    glColor3f(0.505, 0.725, 0.45);
				glBegin(GL_LINES);
					glVertex2i(cx, cy);
					glVertex2i(cx2, cy2);
				glEnd();

				//glDisable(GL_LINE_SMOOTH);
                
                glLineWidth(2.0);
                    glColor3f(0.0, 0.0, 0.0);
                    glLineStipple(1, 0xAA00);
                    glEnable(GL_LINE_STIPPLE);
                    glBegin(GL_LINES);
                        glVertex2i(cx, cy);
                        glVertex2i(cx2, cy2);
                    glEnd();
                    glDisable(GL_LINE_STIPPLE);
                
                
				if (cx2 == cx) {
					if (cy2 > cy) {
						degree = pi / 2.0;
						ax = cx;
						ay = cy2 - (radius);
					}
					else {
						degree = 3 * pi / 2.0;
						ax = cx;
						ay = cy2 + (radius);
					}
				}
				else {
					//slope = (cy2 - cy) / (cx2 - cx);
					//degree = atan(slope);
					degree = atan2(cy2 - cy, cx2 - cx);
					ax = -(radius) * cos(degree) + cx2;
					ay = -(radius) * sin(degree) + cy2;
				}
				
				//drawArrow(ax, ay, degree, (int)(radius / 2));
			}
			else {
                glLineWidth(30);	
                float width = 15;
				glColor3f(0.75, 0.75, 0.6);
				glBegin(GL_LINES);
					glVertex2i(cx, cy);
					glVertex2i(cx, (BORDER / 2) - width + DATA_AREA);
					glVertex2i(cx, (BORDER / 2) + DATA_AREA);
					glVertex2i(cx2-width, BORDER / 2 + DATA_AREA);
					glVertex2i(cx2, (BORDER / 2) - width + DATA_AREA);				
					glVertex2i(cx2, cy2);
				glEnd();
				
				//drawArrow(cx2, cy2 - (radius), pi / 2.0, (int)(radius / 2));
                glLineWidth(1.0);
                if (world[i]->linkStatus[j]) {
                    glColor3f(0.0, 0.0, 0.0);
                    glLineStipple(1, 0xAA00);
                    glEnable(GL_LINE_STIPPLE);
                    glBegin(GL_LINES);
					glVertex2i(cx, cy);
					glVertex2i(cx, (BORDER / 2) + DATA_AREA);
					glVertex2i(cx, (BORDER / 2) + DATA_AREA);
					glVertex2i(cx2, (BORDER / 2) + DATA_AREA);
					glVertex2i(cx2, (BORDER / 2) + DATA_AREA);				
					glVertex2i(cx2, cy2);
                    glEnd();
                    glDisable(GL_LINE_STIPPLE);
                }
			}
		}
        glLineWidth(1.0);
	}
	
	for (i = 0; i < numWorldNodes; i++) {
		cx = BORDER + scalex * world[i]->posx;
		cy = BORDER + DATA_AREA + scaley * world[i]->posy;
		
        glColor3f(0.75, 0.75, 0.6);
		drawCircle(cx, cy, radius);
        if (i == 3)
            glColor3f(0.75, 0.5, 0.2);
        else
            glColor3f(0.3, 0.7, 0.3);
		
		drawCircle(cx, cy, 13 * (scalex / 200.0));
		
		char buf0[4];
		
		char *node_id =  new char[(numToLetter(i+1)).length() +1];
		strcpy(node_id, (numToLetter(i+1)).c_str());
		
        if (node_id!="") {
            sprintf(buf0, "%s",node_id);
            DrawNodeLabel(cx-radius/4.0, cy-radius/4.0, node_id,0.0, 0.0, 0.0); // add a label for each node.
        }else{
            perror ("error occurred!!!");
        }
		delete [] node_id;
		
        //glLineStipple(1, 0xAA00);
        //glEnable(GL_LINE_STIPPLE);
        //glColor3f(0.0, 0.0, 0.0);
		//drawCircleOutline(cx, cy, 19 * (scalex / 200.0));
        //glDisable(GL_LINE_STIPPLE);
	}
}

void drawClock() {
    int yval = HEIGHT + DATA_AREA - 24;
    int sum, i;
    int minutes, seconds;
    double elapsed;
    
    if (!done) {
        struct _timeb now;
		_ftime(&now);
		elapsed = (double)(now.time) + ((double)now.millitm / 1000.0);
        //gettimeofday(&now, NULL);
        //elapsed = now.tv_sec + (now.tv_usec / 1000000.0);        
    }
    else
        elapsed = empiezaConv + (gameLength*60.0);
    
    minutes = ((int)(elapsed - empiezaConv)) / 60;
    seconds = ((int)(elapsed - empiezaConv)) % 60;
    
    char buf[1024];
    if ((minutes < 10) && (seconds < 10))
        sprintf(buf, "0%i:0%i", minutes, seconds);
    else if ((minutes >= 10) && (seconds < 10))
        sprintf(buf, "%i:0%i", minutes, seconds);
    else if ((minutes < 10) && (seconds >= 10))
        sprintf(buf, "0%i:%i", minutes, seconds);
    else if ((minutes >= 10) && (seconds >= 10))
        sprintf(buf, "%i:%i", minutes, seconds);

    glColor3f(0.7f, 0.7f, 0.7f);
    FillBox(WIDTH - 43, yval, 70, 32);
    glColor3f(0.2f, 0.2f, 0.2f);
    OutlineBox(WIDTH - 43, yval, 70, 32);    
	DrawText24(WIDTH - 70, yval-9, buf, 0.0f, 0.0f, 0.0f);
}

void drawWorth() {
    glColor3f(0.8f, 0.8f, 0.8f);
    FillBox(WIDTH / 2, DATA_AREA / 2, WIDTH, DATA_AREA);

    // grid lines
    glColor3f(0.7f, 0.7f, 0.7f);
    double inc = DATA_AREA / 10.0, val;
    int i;
    glBegin(GL_LINES);
    for (val = inc; val < DATA_AREA - 10; val += inc) {
        glVertex2i(0, val);
        glVertex2i(WIDTH, val);
    }
    glEnd();
    
    char buf[1024];
    strcpy(buf, "Joy Level");
    DrawText12(10, DATA_AREA - 15, buf, 0.0f, 0.0f, 0.7f);    
    
    for (i = 0; i < numAgents; i++)
        drawAgentWorth(i);
}

void drawAgentWorth(int id) {
    int x = (id+1) * 25;
    double off = agents[id]->worth * 3;
    int h = (DATA_AREA/2) + off;
    
    glColor3f(agents[id]->r, agents[id]->g, agents[id]->b);
    FillBox(x, h/2, 25, h);
    
    int numLetters = strlen(agents[id]->nombre);
    if (numLetters > 8)
        numLetters = 8;
    char buf[1024];
    //printf("nombre: %s\n", agents[0]->nombre);
    for (int i = 0; i < numLetters; i++) {
        sprintf(buf, "%c", agents[id]->nombre[i]);
        DrawText12(x-4, h-15-(i*15), buf, 0.9f, 0.9f, 0.9f);
    }
}

void DrawAgents() {
	int i;//, j;
	
	double scaley = (HEIGHT - (2 * BORDER)) / (double)(highy - lowy);
	double scalex = (WIDTH - (2 * BORDER)) / (double)(highx - lowx);
	double cx, cy, cx2, cy2, ax, ay; 
	double radius = 5 * (scalex / 200.0);
	//printf("sourceNode: %i; clink: %i\n", agents[0]->sourceNode, agents[0]->clink);
	for (i = 0; i < numAgents; i++) {
		if (agents[i]->clink < 0) {
			//printf("clink < 0\n");
			ax = BORDER + scalex * world[agents[i]->sourceNode]->posx;
			ay = BORDER + DATA_AREA + scaley * world[agents[i]->sourceNode]->posy;			
		}
		else if ((world[agents[i]->sourceNode]->linkTypes[agents[i]->clink] == STRAIGHT) || (world[agents[i]->sourceNode]->linkTypes[agents[i]->clink] == TWO_WAY)) {
			//printf("2nd one\n");
			cx = BORDER + scalex * world[agents[i]->sourceNode]->posx;
			cy = BORDER + DATA_AREA + scaley * world[agents[i]->sourceNode]->posy;
			if (agents[i]->clink >= 0) {
                int l = world[agents[i]->sourceNode]->links[agents[i]->clink];
				cx2 = BORDER + scalex * world[l]->posx;
				cy2 = BORDER + DATA_AREA + scaley * world[l]->posy;
				if ((world[agents[i]->sourceNode]->linkTypes[agents[i]->clink] == TWO_WAY)) {// && (cx == cx2)) {
					if (cy < cy2) {
						cx = cx + 10 * (scalex / 200.0);
						cx2 = cx2 + 10 * (scalex / 200.0);
					}
					else {
						cx = cx - 10 * (scalex / 200.0);
						cx2 = cx2 - 10 * (scalex / 200.0);
					}
				}
				
				ax = cx * (1.0 - agents[i]->progress) + cx2 * agents[i]->progress;
				ay = cy * (1.0 - agents[i]->progress) + cy2 * agents[i]->progress;
                

                double width = world[agents[i]->sourceNode]->capacity[agents[i]->clink]*2.0;                
                double mag = sqrt((cx2 - cx) * (cx2 - cx) + (cy2 - cy) * (cy2 - cy));
                
                ax = ax + (agents[i]->center - 0.5) * width * (fabs(cy2 - cy) / mag);
                ay = ay + (agents[i]->center - 0.5) * width * (fabs(cx2 - cx) / mag);
			}
			else {
				ax = cx;
				ay = cy;
			}
		}
		else {
			//printf("else condition\n");
			cx = BORDER + scalex * world[agents[i]->sourceNode]->posx;
			cy = BORDER + DATA_AREA + scaley * world[agents[i]->sourceNode]->posy;
            int l = world[agents[i]->sourceNode]->links[agents[i]->clink];
			cx2 = BORDER + scalex * world[l]->posx;
			cy2 = BORDER + DATA_AREA + scaley * world[l]->posy;
			double len1 = (cy - ((BORDER / 2) + DATA_AREA));
			double len2 = fabs(cx - cx2);
			double len3 = cy2 - ((BORDER / 2) + DATA_AREA);
			double len = len1 + len2 + len3;
			double spot = len * agents[i]->progress;
			
			if (spot < len1) {
				ax = cx;
				ay = cy * (1.0 - (spot / len1)) + (((BORDER / 2) + DATA_AREA) * (spot / len1));
			}
			else if (spot < (len1 + len2)) {
				ax = cx * (1.0 - ((spot - len1) / len2)) + cx2 * ((spot - len1) / len2);
				ay = ((BORDER / 2) + DATA_AREA);
			}
			else {
				ax = cx2;
				ay = ((BORDER / 2) + DATA_AREA) * (1.0 - ((spot - len1 - len2) / len3)) + cy2 * ((spot - len1 - len2) / len3);
			}
		}
        
/*        double r, g, b;
        if (agentCopy[i]->worth < 0) {  // from black to red
            r = -agentCopy[i]->worth / 50.0;
            if (r > 1.0)
                r = 1.0;
            g = 0.0;
            b = 0.0;
        }
        else {
            r = 0.0;
            b = agentCopy[i]->worth / 50.0;
            if (b > 1.0)
                b = 1.0;
            g = 0.0;
        }*/
        //printf("%f %f %f\n", agentCopy[i]->r, agentCopy[i]->g, agentCopy[i]->b);
		//printf("going to draw the agent at %.1lf, %.1lf\n", ax, ay);
        glColor3f(agents[i]->r, agents[i]->g, agents[i]->b);
		drawCircle(ax, ay, radius);
        glColor3f(0.5f, 0.5f, 0.5f);
		drawCircleOutline(ax, ay, radius);
	}
}

void drawBlockade(int start, int end) {
    int cx, cy;
	double scaley = (HEIGHT - (2 * BORDER)) / (double)(highy - lowy);
	double scalex = (WIDTH - (2 * BORDER)) / (double)(highx - lowx);
    
    glColor3f(0.7f, 0.0f, 0.0f);

    double rise = world[end]->posy - world[start]->posy;
    double run = world[end]->posx - world[start]->posx;
    
    double invslope = -run / rise;
        
    cx = BORDER + scalex * ((0.9 * world[start]->posx + 0.1 * world[end]->posx));
    cy = BORDER + DATA_AREA + scaley * ((0.9 * world[start]->posy + 0.1 * world[end]->posy));
    if ((start == 1) && (end == 2))
        cx -= 10;
    if ((start == 2) && (end == 1))
        cx += 10;
    
    double w = 18.0;
    double x = sqrt((w * w) / ((invslope * invslope) + 1));
    
    double x0 = -x;
    double y0 = x0 * invslope;
    double x1 = x;
    double y1 = x1 * invslope;
    
    glLineWidth(10);
    glBegin(GL_LINES);
    glVertex2i((int)x0+cx,(int)y0+cy);
    glVertex2i((int)x1+cx,(int)y1+cy);
    glEnd();
}

void DrawLinkStatus() {
	int i, j, k, count;
	int cx, cy, linkNum;
	double scaley = (HEIGHT - (2 * BORDER)) / (double)(highy - lowy);
	double scalex = (WIDTH - (2 * BORDER)) / (double)(highx - lowx);

	for (i = 0; i < numWorldNodes; i++) {
		for (j = 0; j < world[i]->numLinks; j++) {
            if (!(world[i]->linkStatus[j])) {
                drawBlockade(i, world[i]->links[j]);
            }
        }
    }
    
    int w = 10, h;
    
    double d, coef;
    
    glLineWidth(1.0);
	for (i = 0; i < numWorldNodes-1; i++) {
		for (j = 0; j < world[i]->numLinks; j++) {
			linkNum = world[i]->links[j];
			cx = BORDER + ((world[i]->posx + world[linkNum]->posx) / 2.0) * scalex;
			if (world[i]->linkTypes[j] == TWO_WAY) {				
				if (world[i]->posy < world[linkNum]->posy) {
                    cx = BORDER + ((0.4 * world[i]->posx + 0.6 * world[linkNum]->posx)) * scalex + 45;
                    cy = BORDER + DATA_AREA + ((0.4 * world[i]->posy + 0.6 * world[linkNum]->posy)) * scaley;
				}
				else {
                    cx = BORDER + ((0.36 * world[i]->posx + 0.64 * world[linkNum]->posx)) * scalex - 45;
                    cy = BORDER + DATA_AREA + ((0.36 * world[i]->posy + 0.64 * world[linkNum]->posy)) * scaley;
				}
			}
			else {
                coef = 0.5;// - (0.05 * (25.0 / (d*d)));
                cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley + 15;
			}
			
			count = 0;
			for (k = 0; k < numAgents; k++) {
				if ((agents[k]->sourceNode == i) && (agents[k]->clink == linkNum))
					count ++;
			}
			
            h = world[i]->capacity[j];
            glColor3f(0.9f, 0.9f, 0.9f);
            FillBox(cx,cy+h/2,w,h);
            
            //glColor3f(0.4f, 0.4f, 0.4f);
            //OutlineBox(cx,cy+h/2,w,h);
                        
            glColor4f(1.0f, 0.0f, 0.0f, 0.2f);
            FillBox(cx,cy+(13.0*h/16.0),w,(3.0*h/8.0)+2);
            
            glColor4f(0.0f, 1.0f, 0.0f, 0.2f);
            FillBox(cx,cy+((3.0*h/8.0)/2.0),w,(3.0*h/8.0));
            
            glColor4f(1.0f, 1.0f, 0.0f, 0.2f);
            FillBox(cx,cy+h/2,w,h/4);
           
            h = count;
            if (h > (world[i]->capacity[j]*2))
                h = world[i]->capacity[j]*2;
            glColor4f(1.0f, 0.0f, 0.0f, 0.75f);
            FillBox(cx,cy+h/4,w-4,h/2);
            
            glColor3f(0.0f, 0.0f, 0.0f);
            h = world[i]->capacity[j];
            glBegin(GL_LINES);
            glVertex2i(cx-w/2,cy+h/2);
            glVertex2i(cx+w/2,cy+h/2);
            glEnd();
		}
	}
}

void DrawLinkStatus2() {
	//secCount++;
	int i, j, k, count;

	int cx, cy, linkNum;
	double scaley = (HEIGHT - (2 * BORDER)) / (double)(highy - lowy);
	double scalex = (WIDTH - (2 * BORDER)) / (double)(highx - lowx);
    char buf[1024];
    
    int w = 10, h;
    
    double coef;
    double destx, desty, theta;
    
    double diffx, diffy, slope, d;
    
    glLineWidth(1.0);	
	
	for (i = 0; i < numWorldNodes-1; i++) {
		for (j = 0; j < world[i]->numLinks; j++) {			
			agentCountNums[i][j] = 0;
		}
	}

		
	for (i = 0; i < numWorldNodes-1; i++) {
		for (j = 0; j < world[i]->numLinks; j++) {
			linkNum = world[i]->links[j];
			cx = BORDER + ((world[i]->posx + world[linkNum]->posx) / 2.0) * scalex;
			if (world[i]->linkTypes[j] == TWO_WAY) {				
				if (world[i]->posy < world[linkNum]->posy) {
                    coef = 0.4;
                    d = WIDTH / 25.0;//45.0;
                    cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                    cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                    diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                    diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                    slope = diffy / diffx;
                    coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                    cy += -diffx * coef;
                    cx += diffy * coef;
				}
				else {
                    coef = 0.4;
                    d = WIDTH / 25.0;//45.0;
                    cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                    cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                    diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                    diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                    slope = diffy / diffx;
                    coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                    cy += -diffx * coef;
                    cx += diffy * coef;
				}
			}
			else {
                coef = 0.55;
                d = WIDTH / 42.0;//45.0;
                cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                slope = diffy / diffx;
                coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                cy -= -diffx * coef;
                cx -= diffy * coef;
			}
			
			count = 0;
			for (k = 0; k < numAgents; k++) {
				if ((agents[k]->sourceNode == i) && (agents[k]->clink == j))
					count ++;
			}
			agentCountNums[i][j] = count;

            glColor3f(0.0f, 0.0f, 0.0f);
            drawPartialCircle(cx, cy, 0, 3.1415926, 33);
            glColor3f(0.7f, 0.0f, 0.0f);
            drawPartialCircle(cx, cy, 0, 3.0 * 3.1415926 / 8.0, 32);
            glColor3f(0.7f, 0.7f, 0.0f);
            drawPartialCircle(cx, cy, 3.0 * 3.1415926 / 8.0, 5.0 * 3.1415926 / 8.0, 32);
            glColor3f(0.0f, 0.5f, 0.0f);
            drawPartialCircle(cx, cy, 5.0 * 3.1415926 / 8.0, 3.1415926, 32);
            glColor3f(0.4f, 0.4f, 0.4f);
            drawPartialCircle(cx, cy, 0, 3.1415926, 20);
            glColor3f(0.7f, 0.7f, 0.7f);
            drawPartialCircle(cx, cy, 0, 3.1415926, 19);
			
			

            sprintf(buf, "%i", count);
            if (count < 10)
                DrawText12(cx-3, cy+3, buf, 0.0, 0.0, 0.9);
            else if (count < 100)
                DrawText12(cx-7, cy+3, buf, 0.0, 0.0, 0.9);
            else
                DrawText12(cx-11, cy+3, buf, 0.0, 0.0, 0.9);
            
            sprintf(buf, "%i", world[i]->capacity[j]);
            if (world[i]->capacity[j] < 10)
                DrawText12(cx - 3, cy + 21, buf, 0.0, 0.0, 0.0);
            else
                DrawText12(cx - 7, cy + 21, buf, 0.0, 0.0, 0.0);
            
            if (count > (2.0 * world[i]->capacity[j]))
                count = (2.0 * world[i]->capacity[j]);
            theta = 3.1415926 * (((2.0 * world[i]->capacity[j]) - count) / (2.0 * world[i]->capacity[j]));
            
            double destx = 25.0 * cos(theta) + cx;
            double desty = 25.0 * sin(theta) + cy;
            
            glColor3f(0.0f, 0.0f, 0.0f);
            glLineWidth(2.0);
            glBegin(GL_LINES);
            glVertex2i(cx, cy);
            glVertex2i(destx, desty);
            glEnd();         
            drawArrow(destx, desty, theta, 8.0);
            glLineWidth(1.0);            
		}
	}
	

		
}

void DrawTolls() {
	int i, j;
	int cx, cy, linkNum;
    char buf[1024];
	double scaley = (HEIGHT - (2 * BORDER)) / (double)(highy - lowy);
	double scalex = (WIDTH - (2 * BORDER)) / (double)(highx - lowx);
        
    int w = 10, h;
    
    double coef;
    double diffx, diffy, slope, d;
    glLineWidth(1.0);
	for (i = 0; i < numWorldNodes-1; i++) {
		for (j = 0; j < world[i]->numLinks; j++) {
			linkNum = world[i]->links[j];
			if (world[i]->linkTypes[j] == TWO_WAY) {
				if (world[i]->posy < world[linkNum]->posy) {
                    coef = 0.6;
                    d = WIDTH / 25.0;//45.0;
                    cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                    cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                    diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                    diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                    slope = diffy / diffx;
                    coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                    cy += -diffx * coef;
                    cx += diffy * coef;
				}
				else {
                    coef = 0.6;
                    d = WIDTH / 25.0;//45.0;
                    cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                    cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                    diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                    diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                    slope = diffy / diffx;
                    coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                    cy += -diffx * coef;
                    cx += diffy * coef;
				}
			}
			else {
                coef = 0.55;
                d = WIDTH / 27.0;//45.0;
                cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                slope = diffy / diffx;
                coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                cy += -diffx * coef;
                cx += diffy * coef;
			}
			
            glColor3f(0.9f, 0.9f, 0.9f);
            FillBox(cx, cy, 53, 25);

            if (abs(world[i]->toll[j]) > 9) {
                sprintf(buf, "0.%i", abs(world[i]->toll[j]));
                DrawText(cx-24, cy-7, buf, 0.0, 0.0, 0.9);
            }
            else {
                sprintf(buf, "0.0%i", abs(world[i]->toll[j]));
                DrawText(cx-24, cy-7, buf, 0.0, 0.0, 0.9);
            }
            
            glColor3f(0.0f, 0.0f, 0.0f);
            FillBox(cx, cy + 19, 53, 15);
            
            sprintf(buf, "TOLL");
            DrawText12(cx-17, cy+14, buf, 0.9f, 0.9f, 0.9f);
            
            glColor3f(0.8f, 0.8f, 0.8f);
            FillBox(cx+19, cy, 14, 25);

            glColor3f(0.5f, 0.5f, 0.5f);
            OutlineBox(cx+19, cy+5, 13, 12);
            OutlineBox(cx+19, cy-6, 13, 12);

            glBegin(GL_LINES);
            glVertex2i(cx+16,cy+4);
            glVertex2i(cx+20,cy+8);
            glVertex2i(cx+20,cy+7);
            glVertex2i(cx+23,cy+4);
            glVertex2i(cx+16,cy-4);
            glVertex2i(cx+20,cy-8);
            glVertex2i(cx+20,cy-7);
            glVertex2i(cx+23,cy-4);
            glEnd();
        }
	}
}

void FillBox(int x, int y, int width, int height) {
	glBegin(GL_POLYGON);
		glVertex2i(x - (width / 2), y + (height / 2));
		glVertex2i(x + (width / 2), y + (height / 2));
		glVertex2i(x + (width / 2), y - (height / 2));
		glVertex2i(x - (width / 2), y - (height / 2));
	glEnd();
}

void OutlineBox(int x, int y, int width, int height) {
	glBegin(GL_LINES);
		glVertex2i(x - (width / 2), y + (height / 2));
		glVertex2i(x + (width / 2), y + (height / 2));

		glVertex2i(x + (width / 2), y + (height / 2));
		glVertex2i(x + (width / 2), y - (height / 2));

		glVertex2i(x + (width / 2), y - (height / 2));
		glVertex2i(x - (width / 2), y - (height / 2));

		glVertex2i(x - (width / 2), y - (height / 2));
		glVertex2i(x - (width / 2), y + (height / 2));
	glEnd();
}

void Resize(int width, int height) {
    WIDTH  = width;
    HEIGHT = height-DATA_AREA;
	
    //printf("WIDTH = %i\n", WIDTH);    
    
    /* Reset the viewport... */
    glViewport(0, 0, width, height);
	
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, (GLfloat)width, 0.0, (GLfloat)height, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
}

void DrawText(GLint x, GLint y, char *s, GLfloat r, GLfloat g, GLfloat b) {
    int lines;
    char* p;
	
	glColor3f(r,g,b);
	glRasterPos2i(x, y);
	for(p = s, lines = 0; *p; p++) {
		if (*p == '\n') {
			lines++;
			glRasterPos2i(x, y-(lines*18));
		}
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *p);
	}
}

void DrawText12(GLint x, GLint y, char *s, GLfloat r, GLfloat g, GLfloat b) {
    int lines;
    char* p;
	
	glColor3f(r,g,b);
	glRasterPos2i(x, y);
	for(p = s, lines = 0; *p; p++) {
		if (*p == '\n') {
			lines++;
			glRasterPos2i(x, y-(lines*18));
		}
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *p);
	}
}

void DrawText24(GLint x, GLint y, char *s, GLfloat r, GLfloat g, GLfloat b) {
    int lines;
    char* p;
	
	glColor3f(r,g,b);
	glRasterPos2i(x, y);
	for(p = s, lines = 0; *p; p++) {
		if (*p == '\n') {
			lines++;
			glRasterPos2i(x, y-(lines*18));
		}
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *p);
	}
}

void SpecialKeys(int key, int x, int y) {
	//printf("special key hit: %i\n", key);
	switch (key) {
		case GLUT_KEY_UP: break;
		case GLUT_KEY_DOWN: break;
		case GLUT_KEY_RIGHT: break;
		case GLUT_KEY_LEFT: break;
	}
}

void RegularKeys(unsigned char key, int x, int y) {
	//printf("regular key hit: %c\n", key);
	switch (key) {
		case 'h': 
			printf("Entering human-control mode\n");
			//hmnControl = true;
			break;
		default: 
			//printf("Entering automated-control mode\n");
			//hmnControl = false; 
			break;
	}
}

void drawCircle(int x, int y, int r) {
	double ang, inc = 3.1415926 / 50;
	
	glBegin(GL_POLYGON);
	for (ang = 0; ang < ((2.0 * 3.1425926) + inc); ang += inc) {
		glVertex2f(x + cos(ang) * r, y + sin(ang) * r);
	}
	glEnd();
}

void drawPartialCircle(int x, int y, double pi_i, double pi_f, int r) {
	double ang, inc = (pi_f - pi_i) / 50;
	
	glBegin(GL_POLYGON);
    glVertex2f(x, y);
	for (ang = pi_i; ang < (pi_f); ang += inc) {
		glVertex2f(x + cos(ang) * r, y + sin(ang) * r);
	}
	glEnd();
}



void drawCircleOutline(int x, int y, int r) {
	double ang, inc = 3.1415926 / 50;
	
	glBegin(GL_LINES);
	for (ang = 0; ang < ((2.0 * 3.1425926) + inc); ang += inc) {
		glVertex2f(x + cos(ang) * r, y + sin(ang) * r);
		glVertex2f(x + cos(ang + inc) * r, y + sin(ang + inc) * r);		
	}
	glEnd();
}

void drawArrow(double x, double y, double degree, int size) {
	glColor3f(0.0, 0.0, 0.0);
	
	//drawCircleOutline((int)x, (int)y, 10);
	double pi = 3.141593;
	int ax = (int)(size * cos(degree + (3 * pi / 4.0)) + x);
	int ay = (int)(size * sin(degree + (3 * pi / 4.0)) + y);
	glBegin(GL_LINES);
		glVertex2i(x, y);
		glVertex2i(ax, ay);

	ax = (int)(size * cos(degree - (3 * pi / 4.0)) + x);
	ay = (int)(size * sin(degree - (3 * pi / 4.0)) + y);

        glVertex2i(x, y);
		glVertex2i(ax, ay);
	glEnd();
}


double distanceFromSegment(Point p, Point start, Point end) {
    double slope = (end.y - start.y) / (end.x - start.x);
    double b = start.y - slope * start.x;
    double x0 = (slope * p.y + p.x - slope * b) / (slope * slope + 1);
    double y0 = slope * x0 + b;
    
    if (x0 > p.x) {
        //printf("it's on the left\n");
        onleft = true;
    }
    else {
        //printf("it's on the right\n");
        onleft = false;
    }
    
    return sqrt(((p.x - x0) * (p.x - x0)) + ((p.y - y0) * (p.y - y0)));
}

double onSegment(Point p, Point start, Point end) {
    //printf("Is (%.2lf, %.2lf) between (%.2lf, %.2lf) and (%.2lf, %.2lf)?\n", p.x, p.y, start.x, start.y, end.x, end.y);
    
    double minx = start.x;
    double miny = start.y;
    
    if (minx > end.x)
        minx = end.x;
    if (miny > end.y)
        miny = end.y;

    double maxx = start.x;
    double maxy = start.y;

    if (maxx < end.x)
        maxx = end.x;
    if (maxy < end.y)
        maxy = end.y;
    
    double margin = 0.1;
    if ((p.x > (minx - margin)) && (p.x < (maxx + margin)) && (p.y > (miny - margin)) && (p.y < (maxy + margin)))
        return distanceFromSegment(p, start, end);
    
    return -1.0;
}

void myMouse(int button, int state,int x, int y) {
	if (state == 1) {
        double scaley = (HEIGHT - (2 * BORDER)) / (double)(highy - lowy);
        double scalex = (WIDTH - (2 * BORDER)) / (double)(highx - lowx);        
        
        Point point;
        point.x = (x - BORDER) / scalex;
        point.y = highy - ((y - BORDER) / scaley);
        
		//printf("left button click (%i): %.2lf, %.2lf\n", state, point.x, point.y);
        
        // see if click is on a link (blockades)
        int i, j;
        Point p1, p2;
        bool found;
        double dist;
		int oldToll;
		int newToll;

        // tolls
        double diffx, diffy, slope, d, coef;
        double cx, cy;
        int linkNum;
        int inc;
        for (i = 0; i < numWorldNodes-1; i++) {
            for (j = 0; j < world[i]->numLinks; j++) {
                linkNum = world[i]->links[j];                
                if (world[i]->linkTypes[j] == TWO_WAY) {
                    if (world[i]->posy < world[linkNum]->posy) {
                        coef = 0.6;
                        d = WIDTH / 25.0;//45.0;
                        cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                        cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                        diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                        diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                        slope = diffy / diffx;
                        coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                        cy += -diffx * coef;
                        cx += diffy * coef;
                    }
                    else {
                        coef = 0.6;
                        d = WIDTH / 25.0;//45.0;
                        cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                        cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                        diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                        diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                        slope = diffy / diffx;
                        coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                        cy += -diffx * coef;
                        cx += diffy * coef;
                    }
                }
                else {
                    coef = 0.55;
                    d = WIDTH / 27.0;//45.0;
                    cx = BORDER + (coef * world[i]->posx + (1.0-coef) * world[linkNum]->posx) * scalex;
                    cy = BORDER + DATA_AREA + (coef * world[i]->posy + (1.0-coef) * world[linkNum]->posy) * scaley;// - 65;
                    diffx = (world[linkNum]->posx - world[i]->posx) * scalex;
                    diffy = (world[linkNum]->posy - world[i]->posy) * scaley;
                    slope = diffy / diffx;
                    coef = sqrt((d * d) / (diffy * diffy + diffx * diffx));
                    cy += -diffx * coef;
                    cx += diffy * coef;
                }
                
                diffy = fabs(cy - ((HEIGHT+DATA_AREA) - y));
                diffx = fabs(cx - x);
                
                //printf("diff = %.0lf, %.0lf\n", diffx, diffy);
                
                int before = world[i]->toll[j];
				oldToll = before;
				int newToll = oldToll;
				
                if ((diffx < 27) && (diffy < 15)) {
                    //pthread_mutex_lock( &count_mutex );
                    //printf("in gl\n"); fflush(stdout);
                    if (button == GLUT_LEFT_BUTTON) {
                        //if (tollChangeFund > 0)
                            inc = 1;
                        //else
                        //    inc = 0;
                    }
                    else {
                        //if (tollChangeFund > 4)
                            inc = 5;
                        //else
                        //    inc = 0;
                    }
                    
                    if (inc != 0) {
                        if ((cy < ((HEIGHT+DATA_AREA)-y)) && (world[i]->toll[j] < 99)){
                            world[i]->toll[j] += inc;
                        }else if ((cy > ((HEIGHT+DATA_AREA)-y)) &&  (world[i]->toll[j] > -99)){
                            world[i]->toll[j] -= inc;
                        }
                        if (world[i]->toll[j] > 99){
                            world[i]->toll[j] = 99;
                        }else if (world[i]->toll[j] < 0){//-99)
                            world[i]->toll[j] = 0;
                        }
                        newToll= world[i]->toll[j];
                        
                        
                        // Log info control data
                        //std::stringstream tollControlStream;
                        struct _timeb now_t3;
						_ftime(&now_t3);
						double elapsed_t3 = (double)(now_t3.time) + ((double)now_t3.millitm / 1000.0);

                        //gettimeofday(&now_t3, NULL);
                        //double elapsed_t3 = now_t3.tv_sec + (now_t3.tv_usec / 1000000.0);
                        double interval3 = elapsed_t3 - empiezaConv;
                        
                        // Time    Node_num  Link_num  oldToll newToll
                        //fprintf(fpCON, "%.2lf %i %i %i %i\n", interval3, i, worldCopy[i].links[j], oldToll, newToll);
                        //fflush(fpCON);
                        
                        //tollChangeFund -= abs(newToll - oldToll);
                    }
                    //pthread_mutex_unlock( &count_mutex );
					//tollControlStream <<std::fixed<< std::setprecision(2) << interval3 << "  " << i <<"  " <<worldCopy[i].links[j] << "  "<< oldToll<<"  "<< newToll;
					//std::string stream_data3 = tollControlStream.str();
					//writeData(stream_data3, DATA_CON);
					
                }
                //totalTollChanges += abs(world[i]->toll[j] - before);
            }
        }
        
        //printf("\n\n");
        
        
	}
	//if (button == GLUT_RIGHT_BUTTON) {
	//	printf("right button: %i, %i\n", x, y);
	//}
	
	Display();
	
}

void Controls() {
    int i, j;

    struct _timeb now;
	_ftime(&empieza);
	double elapsed = ((double)(empieza.time) + ((double)empieza.millitm / 1000.0)) - empiezaConv;

    //gettimeofday(&now, NULL);
    //double elapsed = (now.tv_sec + (now.tv_usec / 1000000.0)) - empiezaConv;
    
    //printf("elapsed = %lf\n", elapsed);
    
    for (i = 0; i < numWorldNodes-1; i++) {
        for (j = 0; j < world[i]->numLinks; j++) {
            if (agentCountNums[i][j] > world[i]->capacity[j]) {
                if (world[i]->toll[j] < 75) {
                    world[i]->lastChange[j] = elapsed;
                    world[i]->quo[j] ++;
                }

                double val = 75 + (elapsed - world[i]->lastChange[j]) / 5.0;
                if (val > 99)
                    val = 99;
                world[i]->toll[j] = (int)val;
            }
            else
                world[i]->toll[j] = world[i]->quo[j];
        }
    }
    
    //exit(1);
}

