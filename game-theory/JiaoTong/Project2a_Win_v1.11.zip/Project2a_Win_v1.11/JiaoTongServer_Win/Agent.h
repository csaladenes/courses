#ifndef AGENT_H
#define AGENT_H

#include "defs.h"
#include "node.h"
#include "mysocket.h"
#include "myStatistics.h"

#define VISITING        0
#define TRAVELING       1
#define DONE_VISITING   2
#define ARRIVED         3

#define GAS_COST        0.079

class Agent {
public:
	Agent();
	Agent(int _ID, int _numNodes, int _start, double *_mu);
	~Agent();
	
    void createConnection(Node *_world[100]);
    
	//void copyAgent(Agent *_a);
	void choose(Node *_world[100]);
	void update(Node *world[100], double _progress, double t);
    void communicate(Node *world[100]);
    double getTime();
    void getNewUtilities();

    char nombre[1024];
    int ID, numNodes;
    
    double timeOfLastAction;
    
    // reward values
    double travelCost, payout, tollCharge;
	double aveOnLink;
	int capacity;
    
    // position
	int sourceNode, clink;
	double center;
	double progress;
    bool willVisit;
    
    // utilities
    double *u;
    double worth;
    myStatistics *s[4];
    
    // state
    int state;
    bool sentMessage;
    
    // color
    float r, g, b;
        
    MySocket *ss;
};

#endif