#include "defs.h"
#include "node.h"
#include "Agent.h"

void *runGame(void *lparam);
//void *logingData(void *lparam);
void readGame(char *fname);
void readParameters(int argc, char *argv[]);
//void log_data();

void countOnLink();

extern void initGl(int argc, char *argv[], const char *title);
//extern void initAgentsCopy(int tipo, int _numAgents);
//extern void updateAgents(Agent **_agents, int _numAgents, int _throughCount);



//extern Node worldCopy[100];
extern double empiezaConv;

Node *world[100];
int numWorldNodes = 0;
int theGoalNode;
double distances[100][100];
int vel[100][100], cap[100][100];

int running_model_type;
unsigned long long callLogDataCount = 0;
double temp_timer;

int throughCount = 0;

Agent **agents;
int numAgents = 0;

double Wealth = 25.0;
double GOrevenue = 0.0;
double tCosts = 0.0;

int gameLength=25;


double highScores[5];
char highNames[5][1024];

bool done = false, highScoreFlag = false;
extern double currentScore;

char yourPseudoname[1024], highScoreMessage[1024];

int sitters[4];

//FILE *fpAGT, *fpSYS, *fpCON;

bool tollLimitations = false;


/* ****************************************
 
./JiaoTong [filename] [numVehicles] [gameLength]
 
******************************************* */
int main(int argc, char *argv[]) {
	srand(time(NULL));

	readParameters(argc, argv);
    
	//pthread_create(&runGameThread, NULL, runGame, NULL);

	DWORD threadid;
	LPVOID dumby = NULL;
	CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) &runGame, NULL, 0, &threadid);

	initGl(argc, argv, "Jiao Tong -- CIS603: Project 2a");
	
	return 0;
}

void *runGame(void *lparam) {
	srand(time(NULL));

	int i, j, l;
	double inc = 0.0;
	int x[100][100];
	    
    Sleep(400);
	//usleep(400000);

    //printf("\n\n\n");
    
	double speed, factor;
	
	//struct timeval previous, now;
	//double mtime, seconds, useconds;    
	//gettimeofday(&previous, NULL);

	struct _timeb previous, now;
	double mtime;
	_ftime(&previous);

    double elapsedTime = 0.0;
    
	while ((gameLength * 60.0) > elapsedTime) {
		
		for (i = 0; i < numWorldNodes; i++) {
			for (j = 0; j < numWorldNodes; j++) {
				x[i][j] = 0;
			}
            sitters[i] = 0;
		}
		for (i = 0; i < numAgents; i++) {
			//printf("(main) sourceNode: %i; clink: %i\n", agents[i]->sourceNode, agents[i]->clink);
			if (agents[i]->clink != -1) {
                l = world[agents[i]->sourceNode]->links[agents[i]->clink];
				x[agents[i]->sourceNode][l] ++;
			}
            else {
                sitters[agents[i]->sourceNode] ++;
            }
		}		
		
		// get the time
		//gettimeofday(&now, NULL);
		_ftime(&now);
		mtime = ((double)(now.time) + ((double)now.millitm / 1000.0)) - ((double)(previous.time) + ((double)previous.millitm / 1000.0));
		elapsedTime = ((double)(now.time) + ((double)now.millitm / 1000.0)) - empiezaConv;

		//printf("elapsed time: %lf\n", elapsedTime);
        
        
        //elapsedTime = (now.tv_sec + (now.tv_usec / 1000000.0)) - empiezaConv;
        //printf("elapsedTime = %lf\n", elapsedTime);
        
		//seconds  = now.tv_sec  - previous.tv_sec;
		//useconds = now.tv_usec - previous.tv_usec;
		//mtime = seconds + (useconds / 1000000.0);
		previous = now;
        
		countOnLink();

		for (i = 0; i < numAgents; i++) {			
			if (agents[i]->clink == -1) {
				inc = 0.0;
			}
			else {
                l = world[agents[i]->sourceNode]->links[agents[i]->clink];
                factor = 0.9 * (1.0 / (1.0 + pow (2.718281828, (0.25 *((double)x[agents[i]->sourceNode][l] - (double)cap[agents[i]->sourceNode][l] )))))+0.1;
                
				speed = vel[agents[i]->sourceNode][l] * factor;
				inc = (mtime / distances[agents[i]->sourceNode][l]) * (speed / 75.0);
			}
			
			agents[i]->update(world, agents[i]->progress + inc, mtime);

			if (agents[i]->sentMessage)
				agents[i]->choose(world);
		}
		
		//updateAgents(agents, numAgents, throughCount);
	}
    
    printf("i finished\n");
    
    char buf[1024];
    for (i = 0; i < numAgents; i++) {
        strcpy(buf, "quit\n");
        agents[i]->ss->SendMessage(buf, strlen(buf));
        //close(agents[i]->ss->m_hSocket);
    }
    
    //usleep(50000);
	Sleep(100);
    done = true;

	return 0;
}

void countOnLink() {
	int i, j;
	
	for (i = 0; i < numWorldNodes; i++) {
		for (j = 0; j < world[i]->numLinks; j++) {
			world[i]->numOnLink[j] = 0;
		}
	}

	for (i = 0; i < numAgents; i++) {
		if (agents[i]->clink >= 0)
			world[agents[i]->sourceNode]->numOnLink[agents[i]->clink] ++;
	}
}

void readGame(char *fname) {
	char fnombre[1024];
	sprintf(fnombre, "..//games//%s.txt", fname);
	FILE *fp = fopen(fnombre, "r");
	
	fscanf(fp, "%i", &numWorldNodes);
	int i, j;
	int numlinks, links[4], linkTypes[4];
	int velocity[4], capacity[4];
	double posx, posy;
	char l[20];
	for (i = 0; i < numWorldNodes; i++) {
		fscanf(fp, "%lf %lf %i", &posx, &posy, &numlinks);
		//printf("numlinks = %i\n", numlinks);
		for (j = 0; j < numlinks; j++) {
			fscanf(fp, "%s", l);
			//printf("%i (%i): parsing %s\n", j, numlinks, l);
			if (l[0] == 's')
				linkTypes[j] = STRAIGHT;
			else if (l[0] == 't')
				linkTypes[j] = TWO_WAY;
			else if (l[0] == 'b')
				linkTypes[j] = BELOW;
			else {
				printf("don't recognize link type: %c\n", l[0]);
				exit(1);
			}
			links[j] = atoi(l+1);
			
			int c = 1;
			while (l[c] != '_')
				c++;
			c ++;
			velocity[j] = atoi(l+c);
			
			while (l[c] != '_')
				c++;
			c ++;
			capacity[j] = atoi(l+c);
			
			vel[i][links[j]] = velocity[j];
			cap[i][links[j]] = capacity[j];	
		}
		for (j = numlinks; j < 4; j++)
			links[j] = linkTypes[j] = -1;
		
		world[i] = new Node(posx, posy, links, linkTypes, velocity, capacity);
	}
	fscanf(fp, "%i", &theGoalNode);
	
	double x, y;
	for (i = 0; i < numWorldNodes; i++) {
		for (j = 0; j < numWorldNodes; j++) {
			x = world[i]->posx - world[j]->posx;
			y = world[i]->posy - world[j]->posy;
			distances[i][j] = sqrt(x * x + y * y);
			//printf("dist from %i to %i = %.3lf\n", i, j, distances[i][j]);
		}
	}
	
	fclose(fp);
}

void readParameters(int argc, char *argv[]) {
    int agentType = RANDOM_TYPE; // default as random
	
    
	if (argc >= 2)
		readGame(argv[1]);
	else {
		printf("error: no data file provided\n");
		exit(1);
	}
	
    printf("filename: %s\n", argv[1]);
	if (argc >= 3)
		numAgents = atoi(argv[2]);
	printf("numAgents: %i\n",numAgents);
    
    if (argc >= 4)
        gameLength = atoi(argv[3]);
	printf("gameLength: %i minutes\n", gameLength);
    		
	agents = new Agent*[numAgents];
	//agents = new Dijkstra*[numAgents];	
	int i;
    
    double given[4] = {4.0, 6.0, 4.0, 4.0};// check
	for (i = 0; i < numAgents; i++) {
        agents[i] = new Agent(i, numWorldNodes, rand() % numWorldNodes, given);
        agents[i]->createConnection(world);
	}
}



