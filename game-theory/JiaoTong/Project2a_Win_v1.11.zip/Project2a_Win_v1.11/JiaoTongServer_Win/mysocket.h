#ifndef MYSOCKET_H
#define MYSOCKET_H

#include "defs.h"

#define HOST_NAME_SIZE      255
#define HOST_PORT			3060

class MySocket{
public:
	MySocket(int port);
	~MySocket();
	void AcceptEm();
	int SendMessage(char *, int len);
	int ReadMessage(char *);
	bool connected() { return m_hSocket != SOCKET_ERROR; };

	int SendMessage(char *num,char *message, int len);
	int ReadMessageInt(char *message);
	void sendmsg(double score);
	void buildmsg(char *message,char *mensaje);
	int readmsg();
	void readmsg(char *buf);

	int m_hSocket;
	int hServerSocket;
	struct sockaddr_in Address;
};

#endif  //__MYSOCKET_H__