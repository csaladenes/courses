#ifndef NODE_H
#define	NODE_H

#include "defs.h"

class Node {
public:
	Node();
	Node(double _posx, double _posy, int _numLinks, int _links[4]);
	~Node();
	
	double posx, posy;
	int numLinks;
	int links[4];
};

#endif