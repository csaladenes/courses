#include "node.h"

Node::Node() {
}

Node::Node(double _posx, double _posy, int _numLinks, int _links[4]) {
	posx = _posx;
	posy = _posy;
    numLinks = _numLinks;
    
	int i;
	for (i = 0; i < 4; i++) {
		links[i] = _links[i];
	}
	
	//printf("node created at (%.1lf, %.1lf) with %i links (%i %i %i %i)\n", posx, posy, numLinks, links[0], links[1], links[2], links[3]);
}

Node::~Node() {
}
