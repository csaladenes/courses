#ifndef DEFS_H
#define DEFS_H

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <winsock.h>
#include <conio.h>
#include <time.h>
#include <math.h>
#include <windows.h>
#include <io.h>
#include <sys/types.h>
#include <sys/timeb.h>

#define STRAIGHT	0
#define TWO_WAY		1
#define BELOW		2

//#define RANDOM_TYPE		0
//#define DIJKSTRA_TYPE	1
//#define STATIC_TYPE     2

#define CONNECT_PORT    3000


#endif