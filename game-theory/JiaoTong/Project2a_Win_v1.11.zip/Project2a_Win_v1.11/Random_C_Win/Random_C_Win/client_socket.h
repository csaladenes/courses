#ifndef CLIENTSOCKET_H
#define CLIENTSOCKET_H

#include "defs.h"

#define HOST_NAME_SIZE      255
#define HOST_PORT			3060

extern bool quit;

class ClientSocket {
public:
	ClientSocket(char *hostname, int port);
	int SendMessage(char *, int len);	
	int ReadMessage(char *);

	bool connected() { return m_hSocket != SOCKET_ERROR; };

	int m_hSocket;
};

#endif