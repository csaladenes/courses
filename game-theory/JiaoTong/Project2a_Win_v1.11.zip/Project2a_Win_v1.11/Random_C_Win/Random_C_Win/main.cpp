#include "defs.h"
#include "client_socket.h"
#include "node.h"
#include "Status.h"

// functions you probably shouldn't change (except to specify a different agent color in setUp)
void setUp(char *hostname, double _ID, char *nombre);
void play();
void act();
bool readStatusMessage();

// functions that you will need to update
int selectAction();
void updateInternalModels();

// your connection to the JiaoTong server
ClientSocket *cs;

// the graph of the world, which is initialized in the function setUp
Node *world[100];
int numWorldNodes;

// information updates from the server are stored in this object
Status status;

/* ***********************************************
 //
 //  ./RandomAgent [hostname] [ID] [name]
 //
 *********************************************** */
int main (int argc, char *argv[]) {
    srand(time(NULL));
    
    setUp(argv[1], atoi(argv[2]), argv[3]);

    play();
    
    return 0;
}


// This function selects the next link to traverse from currentNode
//      0 means the agent selects link[0]
//      1 means the agent selects link[1]
// ********* You will need to modify this function
int selectAction() {
    return rand() % world[status.currentNode]->numLinks;
}

// This function is called after new information is obtained about the world
// Information is stored in the information variables defined at the beginning of the class
// ********* You should use this function to update you agent's estimates/model of the world (if you choose to model the world)
void updateInternalModels() {
}

// You shouldn't need to modify this function
void play() {
    
    while (true) {
        if (!readStatusMessage())
            break;
        
        updateInternalModels();
        
        act();
    }
}

// You shouldn't need to modify this function
void act() {
    // move to the next node
    int a = selectAction();
    
    
    // visit the node if it has positive utility
    char buf[1024];
    int destination = world[status.currentNode]->links[a];
    if (status.currentUtilitiesforVisitingNodes[destination] > 0)
        sprintf(buf, "%i Y\n", a);
    else    
        sprintf(buf, "%i N\n", a);

    printf("Sent: %s\n", buf);
    cs->SendMessage(buf, (int)strlen(buf));
}

// You shouldn't modify this function
// This function gets an update from the server each time your car reaches a new node
// The server supplies you with the following information:
//      1. Reward/cost information: status.travelCost: the cost (measured in happiness units) you incurred for traveling over the last link
//                                  status.payout: the number of happiness units you got for arriving at the current node
//                                  status.tollCharge: the amount of toll charge you incurred for traveling the latest link
//      2. status.currentNode: the current node position your car is at in the world (value between 0-3)
//      3. status.currentUtilitiesforVisitingNode [array of 4]: The number of happiness units you will get in the future for arriving at each of the 4 nodes    
//		4. status.aveOnLink and status.capacity give the average number of vehicles during your voyayge on the link, and the capacity of that link
bool readStatusMessage() {
    char buf[1024];
    
    cs->ReadMessage(buf);

    //printf("%s\n", buf);
    // parse my latest payoffs
    strcpy(buf, strtok(buf, " "));  // reads the string "Results:"
    if (buf[0] == 'q')
        return false;
    
    status.travelCost = atof(strtok(NULL, " "));
    status.payout = atof(strtok(NULL, " "));
    status.tollCharge = atof(strtok(NULL, "\n"));
    printf("Results: %lf %lf %lf\n", status.travelCost, status.payout, status.tollCharge); fflush(stdout);
    
    // parse my current position in the world
    strtok(NULL, " ");   // reads the string "Position:"
    status.currentNode = atoi(strtok(NULL, "\n"));
    printf("Position: %i\n", status.currentNode); fflush(stdout);
    
    // parse my utilities for visiting each node
    strtok(NULL, " " );  // reads the strong "Utilities:"
    for (int i = 0; i < 4; i++)
        status.currentUtilitiesforVisitingNodes[i] = atof(strtok(NULL, " \n"));
    printf("Utilities: %lf %lf %lf %lf\n", status.currentUtilitiesforVisitingNodes[0],
           status.currentUtilitiesforVisitingNodes[1],
           status.currentUtilitiesforVisitingNodes[2],
           status.currentUtilitiesforVisitingNodes[3]); fflush(stdout);
    
	// parse linkState
    strtok(NULL, " " );  // reads the strong "LinkState:"
	status.aveOnLink = atof(strtok(NULL, " "));
	status.capacity = atoi(strtok(NULL, "\n"));
	printf("LinkState: %lf %i\n", status.aveOnLink, status.capacity);

    return true;
}

// **********************************************************************************
//
// Theoretically, you shouldn't have to alter anything below this point in this file
//      unless you want to change the color of your agent
//
// **********************************************************************************
void setUp(char *hostname, double _ID, char *nombre) {
    // get a connection
    cs = new ClientSocket(hostname, CONNECT_PORT + _ID);
    
    // read in the map of the world
    char buf[1024];
    cs->ReadMessage(buf);
    numWorldNodes = atoi(strtok(buf, "\n"));
    printf("numWorldNodes = %i\n", numWorldNodes);
    
    int i, j;
    double posx, posy;
    int numLinks, links[4];    
    for (i = 0; i < numWorldNodes; i++) {
        posx = atof(strtok(NULL, " "));
        posy = atof(strtok(NULL, " "));
        numLinks = atoi(strtok(NULL, " "));
        for (j = 0; j < 4; j++) {
            if (j < numLinks)
                links[j] = atoi(strtok(NULL, " \n"));
            else
                links[j] = -1;
        }
        
        world[i] = new Node(posx, posy, numLinks, links);
    }
    
    // send the agents name and color
    sprintf(buf, "%s\n%lf %lf %lf\n", nombre, 0.0, 0.5, 0.0); //last three values specify the agents color    
    cs->SendMessage(buf, (int)strlen(buf));
}