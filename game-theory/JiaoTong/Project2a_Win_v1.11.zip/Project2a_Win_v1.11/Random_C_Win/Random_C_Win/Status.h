#ifndef Random_Status_h
#define Random_Status_h

#include "defs.h"

class Status {
public:
    Status();
    ~Status();

    double travelCost, payout, tollCharge;
    int currentNode;
    double currentUtilitiesforVisitingNodes[4];
	double aveOnLink;
	int capacity;
};


#endif
