#include "Agent.h"

extern double ffwd;

Agent::Agent() {
    printf("incompleted Agent constructor\n");
    exit(1);
}

Agent::Agent(int _ID, int _numNodes, int _start, double *_mu) {
	sourceNode = _start;
    progress = 0.0;
	clink = -1;
	progress = 0.0;
    center = (rand() % 21) / 20.0;
    worth = 0.0;
    ID = _ID;
    numNodes = _numNodes;
    
    //mu = new double[numNodes];
    u = new double[numNodes];
//    double mu, sigma;
    for (int i = 0; i < numNodes; i++) {
        u[i] = _mu[i];
        //mu[i] = _mu[i];
        
//        mu = _mu[i];// + 1.0 * (rand() / (double)RAND_MAX);
//        sigma = 0.1;// + 0.3 * (rand() / (double)RAND_MAX);
//        s[i] = new myStatistics(NORMAL, mu, sigma);
    }
    
    ss = new MySocket(CONNECT_PORT + _ID);
    
    //printf("state = DONE_VISITING\n");
    sentMessage = false;
    
    travelCost = tollCharge = payout = 0.0;
    timeOfLastAction = getTime();
    
    willVisit = false;
    state = DONE_VISITING;
    
    getNewUtilities();
    
    center = (rand() % 21) / 20.0;
    aveOnLink = 0;
    capacity = -1;
    
    //printf("center = %lf\n", center);
}

Agent::~Agent() {
    delete u;
    //for (int i = 0; i < numNodes; i++)
    //    delete s[i];    
}

void Agent::createConnection(Node *_world[100]) {
    ss->AcceptEm();
    
    // send the world to the agent, as well as its start node
    int i, j;
    char buf[1024], add[1024];
    sprintf(buf, "%i\n", numNodes);
    for (i = 0; i < numNodes; i++) {
        sprintf(add, "%.1lf %.1lf %i", _world[i]->posx, _world[i]->posy, _world[i]->numLinks);
        for (j = 0; j < _world[i]->numLinks; j++) {
            sprintf(add, "%s %i", add, _world[i]->links[j]);
        }
        strcat(buf, add);
        strcat(buf, "\n");
    }
    sprintf(buf, "%s%i\n", buf, sourceNode);
    //printf("%s", buf);
    ss->SendMessage(buf, (int)strlen(buf));
    
    // read the agent's name and color
    ss->ReadMessage(buf);
    char *temp = strtok(buf, "\n");
    strcpy(nombre, temp);
    printf("nombre: %s\n", nombre);
    r = atof(strtok(NULL, " "));
    g = atof(strtok(NULL, " "));
    b = atof(strtok(NULL, " "));
    printf("color = (%lf %lf %lf)\n", r, g, b);
    
    //printf("nombre: %s\n", nombre);
}


void Agent::choose(Node *_world[100]) {
    char buf[1024];
        
	//printf("to do recv in ReadMessage\n");
	//int NumBytes = recv(ss->hSocket, buf, 1024, MSG_PEEK);
    //printf("NumBytes = %i\n", NumBytes);
    //if (NumBytes < 1)
    //    return;

    
    //printf("to read ... ");
    ss->ReadMessage(buf);
    //printf("%s\n", buf);
    
    clink = atoi(buf);
    if (clink >= _world[sourceNode]->numLinks) {
        printf("invalid action received\n");
        clink = -1;
    }
    else {
        state = TRAVELING;
        travelCost = 0.0;
        payout = 0.0;
        tollCharge = _world[sourceNode]->toll[clink];
        timeOfLastAction = getTime();
        
        if (buf[2] == 'N') {
            willVisit = false;
            //printf("setting willVisit to false\n");
        }
        else {
            willVisit = true;
            //printf("setting willVisit to true\n");
        }
        //printf("state = TRAVELING (%i)\n", (bool)willVisit);
    }
    
    aveOnLink = 0.0;
    //printf("clink = %i\n", clink);
    
    sentMessage = false;
}

void Agent::update(Node *world[100], double _progress, double t) {
    if ((state == ARRIVED) && willVisit) {
        // check to see if visit time has elapsed
        double tau = getTime();
        //printf("checking to see if my visit is over: %lf\n", tau - timeOfLastAction);

        if ((tau - timeOfLastAction) >= 0.0) {
            willVisit = false;
            timeOfLastAction = tau;
            state = DONE_VISITING;
            //printf("state = DONE_VISITING (%i)\n", (bool)willVisit);
            payout = u[sourceNode];
            
            // get new utilities
            getNewUtilities();
            
        }
        else {
            return;
        }
    }
    else if (clink >= 0)
        aveOnLink += (world[sourceNode]->numOnLink[clink] * t);
    
    
	progress = _progress;
	if (progress >= 1.0) {
        travelCost = getTime() - timeOfLastAction;
        //printf("travelCost = %lf\n", travelCost);
        if (willVisit) {
            state = ARRIVED;
            //printf("state = ARRIVED (%i)\n", (bool)willVisit);
            timeOfLastAction = getTime();
        }
        else {
            state = DONE_VISITING;
            //printf("state = DONE_VISITING (%i)\n", (bool)willVisit);
            timeOfLastAction = getTime();
        }
        if (clink >= 0)
            capacity = world[sourceNode]->capacity[clink];
        aveOnLink /= travelCost;
        //printf("aveOnLink = %lf\n", aveOnLink);
        
        sourceNode = world[sourceNode]->links[clink];
		progress = 0.0;
        clink = -1;        
	}
    
    if (!sentMessage && (state == DONE_VISITING))
        communicate(world);
}

void Agent::communicate(Node *world[100]) {
    char buf[1024];
    
    worth += payout - travelCost*GAS_COST*ffwd - (tollCharge / 100.0);
    //printf("worth = %lf\n", worth);
    
    sprintf(buf, "Results: %lf %lf %lf\n", travelCost*GAS_COST*ffwd, payout, tollCharge / 100.0);
    sprintf(buf, "%sPosition: %i\n", buf, sourceNode);
    sprintf(buf, "%sUtilities: %lf %lf %lf %lf\n", buf, u[0], u[1], u[2], u[3]);
    sprintf(buf, "%sLinkState: %.2lf %i\n", buf, aveOnLink, capacity);

    //if (state == ARRIVED)
    //    sprintf(buf, "%svisitOption: true\n", buf);
    //else
    //    sprintf(buf, "%svisitOption: false\n", buf);
    
    //printf("%s\n", buf);
    ss->SendMessage(buf, (int)strlen(buf));
    
    sentMessage = true;
}

double Agent::getTime() {
    struct timeval now;
    gettimeofday(&now, NULL);
    return (now.tv_sec + (now.tv_usec / 1000000.0));
}

void Agent::getNewUtilities() {
/*    int i;
    for (i = 0; i < numNodes; i++) {
        //u[i] = s[i]->getSample();
        u[i] = 0.0;
    }
    
    int desiredNode = 3;//rand() % numNodes;
    //printf("chose %i\n", desiredNode);
    u[desiredNode] = 5.0;*/
}
