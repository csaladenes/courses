#include "defs.h"
#include "node.h"
#include "Agent.h"

void *runGame(void *lparam);
//void *logingData(void *lparam);
void readGame(char *fname);
void readScenario(char *fname);
void readParameters(int argc, char *argv[]);
void countOnLinks();
//void log_data();

pthread_t runGameThread;

extern void initGl(int argc, char *argv[], const char *title);

extern double empiezaConv;

Node *world[100];
int numWorldNodes = 0;
int theGoalNode;
double distances[100][100];
int vel[100][100], cap[100][100];

int running_model_type;
unsigned long long callLogDataCount = 0;
double temp_timer;

int throughCount = 0;

Agent **agents;
int numAgents = 0;

double Wealth = 25.0;
double GOrevenue = 0.0;
double tCosts = 0.0;

int gameLength=25;


double highScores[5];
char highNames[5][1024];

bool done = false, highScoreFlag = false;
extern double currentScore;

char yourPseudoname[1024], highScoreMessage[1024];

pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER;

double utils[4];

int sitters[4];

//FILE *fpAGT, *fpSYS, *fpCON;

bool tollLimitations = false;

double ffwd = 1;


/* ****************************************
 
./JiaoTong [world_filename] [scenario_filename] [numVehicles] [gameLength] [speed=i]
 
******************************************* */
int main(int argc, char *argv[]) {
	srand(time(NULL));

	readParameters(argc, argv);
    
	pthread_create(&runGameThread, NULL, runGame, NULL);
	//pthread_create(&logDataThread, NULL, logingData, NULL);
	initGl(argc, argv, "Jiao Tong -- CIS603: Project 2a");
	
	return 0;
}

void *runGame(void *lparam) {
	int i, j, l;
	double inc = 0.0;
	int x[100][100];
	    
    usleep(400000);

    //printf("\n\n\n");
    
	double speed, factor;
	
	struct timeval previous, now;
	double mtime, seconds, useconds;    
	gettimeofday(&previous, NULL);

    double elapsedTime = 0.0;
    
	while ((gameLength * 60.0) > (elapsedTime*ffwd)) {
		
		for (i = 0; i < numWorldNodes; i++) {
			for (j = 0; j < numWorldNodes; j++) {
				x[i][j] = 0;
			}
            sitters[i] = 0;
		}
		for (i = 0; i < numAgents; i++) {
			if (agents[i]->clink != -1) {
                l = world[agents[i]->sourceNode]->links[agents[i]->clink];
				x[agents[i]->sourceNode][l] ++;
			}
            else {
                sitters[agents[i]->sourceNode] ++;
            }
		}		
		
		// get the time
		gettimeofday(&now, NULL);
        
        
        elapsedTime = (now.tv_sec + (now.tv_usec / 1000000.0)) - empiezaConv;
        //printf("elapsedTime = %lf\n", elapsedTime);
        
		seconds  = now.tv_sec  - previous.tv_sec;
		useconds = now.tv_usec - previous.tv_usec;
		mtime = seconds + (useconds / 1000000.0);
		previous = now;
        
        countOnLinks();
        
		for (i = 0; i < numAgents; i++) {			
			if (agents[i]->clink == -1) {
				inc = 0.0;
			}
			else {
                l = world[agents[i]->sourceNode]->links[agents[i]->clink];
                factor = 0.9 * (1.0 / (1.0 + pow (2.718281828, (0.25 *((double)x[agents[i]->sourceNode][l] - (double)cap[agents[i]->sourceNode][l] )))))+0.1;
                
				speed = vel[agents[i]->sourceNode][l] * factor * ffwd;
				inc = (mtime / distances[agents[i]->sourceNode][l]) * (speed / 75.0);
			}
			
			agents[i]->update(world, agents[i]->progress + inc, mtime);

			if (agents[i]->sentMessage)
				agents[i]->choose(world);
		}
		
		//updateAgents(agents, numAgents, throughCount);
	}
    
    printf("i finished\n");
    
    FILE *resultsfp = fopen("results.txt", "w");
    
    char buf[1024];
    for (i = 0; i < numAgents; i++) {
        fprintf(resultsfp, "%i: %s\t%lf\n", i, agents[i]->nombre, agents[i]->worth);
        
        strcpy(buf, "quit\n");
        agents[i]->ss->SendMessage(buf, strlen(buf));
        close(agents[i]->ss->hSocket);
    }
    
    fclose(resultsfp);
    
    usleep(50000);
    done = true;
}

void countOnLinks() {
    int i, j;
    
    for (i = 0; i < numWorldNodes; i++) {
        for (j = 0; j < world[i]->numLinks; j++) {
            world[i]->numOnLink[j] = 0;
        }
    }
    
    for (i = 0; i < numAgents; i++) {
        if (agents[i]->clink >= 0) {
            world[agents[i]->sourceNode]->numOnLink[agents[i]->clink] ++;
        }
    }
    
/*    for (i = 0; i < numWorldNodes; i++) {
        for (j = 0; j < world[i]->numLinks; j++) {
            printf("%i ", world[i]->numOnLink[j]);
        }
        printf("\n");
    }
    printf("\n");*/
}

void readGame(char *fname) {
	char fnombre[1024];
	sprintf(fnombre, "..//games//%s.txt", fname);
	FILE *fp = fopen(fnombre, "r");
	
	fscanf(fp, "%i", &numWorldNodes);
	int i, j;
	int numlinks, links[4], linkTypes[4];
	int velocity[4], capacity[4];
	double posx, posy;
	char l[20];
	for (i = 0; i < numWorldNodes; i++) {
		fscanf(fp, "%lf %lf %i", &posx, &posy, &numlinks);
		//printf("numlinks = %i\n", numlinks);
		for (j = 0; j < numlinks; j++) {
			fscanf(fp, "%s", l);
			//printf("%i (%i): parsing %s\n", j, numlinks, l);
			if (l[0] == 's')
				linkTypes[j] = STRAIGHT;
			else if (l[0] == 't')
				linkTypes[j] = TWO_WAY;
			else if (l[0] == 'b')
				linkTypes[j] = BELOW;
			else {
				printf("don't recognize link type: %c\n", l[0]);
				exit(1);
			}
			links[j] = atoi(l+1);
			
			int c = 1;
			while (l[c] != '_')
				c++;
			c ++;
			velocity[j] = atoi(l+c);
			
			while (l[c] != '_')
				c++;
			c ++;
			capacity[j] = atoi(l+c);
			
			vel[i][links[j]] = velocity[j];
			cap[i][links[j]] = capacity[j];	
		}
		for (j = numlinks; j < 4; j++)
			links[j] = linkTypes[j] = -1;
		
		world[i] = new Node(posx, posy, links, linkTypes, velocity, capacity);
	}
	fscanf(fp, "%i", &theGoalNode);
	
	double x, y;
	for (i = 0; i < numWorldNodes; i++) {
		for (j = 0; j < numWorldNodes; j++) {
			x = world[i]->posx - world[j]->posx;
			y = world[i]->posy - world[j]->posy;
			distances[i][j] = sqrt(x * x + y * y);
			//printf("dist from %i to %i = %.3lf\n", i, j, distances[i][j]);
		}
	}
	
	fclose(fp);
}

void readScenario(char *fname) {
	char fnombre[1024];
	sprintf(fnombre, "..//games//%s.txt", fname);
	FILE *fp = fopen(fnombre, "r");
    
    fscanf(fp, "%lf", &(utils[0]));
    fscanf(fp, "%lf", &(utils[1]));
    fscanf(fp, "%lf", &(utils[2]));
    fscanf(fp, "%lf", &(utils[3]));

    fclose(fp);
}

void readParameters(int argc, char *argv[]) {
    int agentType = RANDOM_TYPE; // default as random
	
	int i;    		
    for (i = 5; i < argc; i++) {
        if (!strncmp(argv[i], "ffwd", 4)) {
            ffwd = atof(argv[i]+5);
            printf("ffwd = %lf\n", ffwd);
        }
    }
    
	if (argc >= 2)
		readGame(argv[1]);
	else {
		printf("error: no world map provided\n");
		exit(1);
	}
    
    if (argc >= 3)
        readScenario(argv[2]);
    else {
		printf("error: no reward scenario provided\n");
		exit(1);
	}
	
	if (argc >= 4)
		numAgents = atoi(argv[3]);
	printf("numAgents: %i\n",numAgents);
    
    if (argc >= 5)
        gameLength = atoi(argv[4]);
	printf("gameLength: %i minutes\n", gameLength);

    
    
    double lambda;
	agents = new Agent*[numAgents];
	//agents = new Dijkstra*[numAgents];	
    
    //double given[4] = {4.0, 6.0, 4.0, 4.0};// check
	for (i = 0; i < numAgents; i++) {
        agents[i] = new Agent(i, numWorldNodes, rand() % numWorldNodes, utils);
        agents[i]->createConnection(world);
	}
}



